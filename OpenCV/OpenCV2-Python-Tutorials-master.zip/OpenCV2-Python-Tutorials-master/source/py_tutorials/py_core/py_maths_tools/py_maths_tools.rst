.. _Mathematical_Tools:

Mathematical Tools in OpenCV
********************************
